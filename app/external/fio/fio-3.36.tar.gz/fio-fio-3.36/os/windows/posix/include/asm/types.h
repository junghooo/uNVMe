#ifndef ASM_TYPES_H
#define ASM_TYPES_H

typedef unsigned short __u16;
typedef unsigned int __u32;
typedef unsigned long long __u64;

#endif /* ASM_TYPES_H */
